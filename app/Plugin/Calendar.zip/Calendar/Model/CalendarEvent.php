<?php

class CalendarEvent extends CalendarAppModel {

	public $actsAs = array( 'Revision' ,  'Containable','Tags.Taggable');	

	public $validate = array(
    'title' => array(
        'rule'=>array('minLength', 1), 
        'message'=>'Title is required' )
	);
	
	public $hasOne = array(
		'Content' => array(
			'className' => 'Content',
			//'conditions' => array('Content.class_name' => 'events'),
			'foreignKey' => 'foreign_id', 
			'dependent' => true
		)
	);  
	
			
}
