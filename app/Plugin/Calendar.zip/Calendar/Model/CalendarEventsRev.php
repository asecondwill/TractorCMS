<?php

class CalendarEventsRev extends CalendarAppModel {

}