<?php
//	App::uses('CalendarAppModel', 'Calendar.Model');
class CalendarCategory extends CalendarAppModel {
	
//	var $name = 'Eventcategory';
	var $displayField = 'title';
	var $actsAs = array('Revision', 'Containable' ,'Tags.Taggable'	);	
	
	var $validate = array(
		'title' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed
/*
	var $hasMany = array(
		'Event' => array(
			'className' => 'Event',
			'foreignKey' => 'eventcategory_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);
*/	
	var $hasOne = array(
		'Content' => array(
			'className' => 'Content',
//			'conditions' => array('Content.class_name' => 'eventcategories'),
			'foreignKey' => 'foreign_id', 
			'dependent' => true
		)
	);
}
