<?php
class CalendarCategoriesController extends CalendarAppController {

//	var $name = 'Eventcategories';
	var $helpers = array('Html', 'Time', 'mTree', 'Js',  'Tree', 'Image', 'TextImage', 'TractorInputs', 'Tags.TagCloud', 'Paginator', 'Number');
	var $uses = array('Calendar.CalendarCategory');

	public $paginate= array('limit' => 30,'order'=>array('Content.lft'=>'asc')); 

	var $permissions = array(
        'admin_index' => array('Editor'),
        'admin_add' => array('Editor'),
        'admin_edit' => array('Editor'),
        'admin_delete' => array('Editor'),                 
    );
	 function beforeFilter() { 
    	$this->Auth->allow('view',  'index'); 
    	
    	parent::beforeFilter();   
    	
    } 

	function index($slug) {
		
    	$content = $this->CalendarCategory->Content->find('first', array('conditions'=>array('Content.slug'=>$slug)));
    	$this->set('content', $content);

		$path  = $this->CalendarCategory->Content->getPath($content['Content']['id']);
		$this->set('path', $path);
		
		$event_categories = $this->CalendarCategory->Content->find('threaded', array(
			'fields' => array('id', 'title', 'path', 'slug',  'lft', 'rght', 'parent_id'), 
			'order' => 'lft ASC',
			'conditions' => array('Content.class_name'=>'eventcategories', 'Content.action_name'=>'view')
			));
			
		$categories = $this->CalendarCategory->find('all', array('conditions'=>array('Content.parent_id'=> null)));
		
		$this->set('categories', $categories);										
		$this->set('event_categories', $event_categories);									
	}

	function view($slug = null) {
			
		if (!$slug) {
			$this->Session->setFlash(sprintf(__('Invalid %s'), 'page'));
			$this->redirect(array('action' => 'index'));
		}

		$eventcategory = $this->CalendarCategory->find('first', array('conditions'=>array('Content.slug' => $slug)));
		$path  = $this->CalendarCategory->Content->getPath($eventcategory['Content']['id']);
		
				
		
		
		$this->set('content', $eventcategory);		
		$this->set('path', $path);		
		$this->cacheAction = true;
		
		if (!empty($page['Content']['layout'])) $this->layout =  basename($page['Content']['layout'], '.ctp');
		if (!empty($page['Content']['view']))$this->render(basename($page['Content']['view'], '.ctp')) ;
		
/* moved to content model		
		$this->CalendarCategory->Content->bindModel(array('belongsTo' => array('Event' => array(
																		'Content.className' =>'Event',
																		'foreignKey' => 'foreign_id', 
																		))));
*/		
		$this->CalendarCategory->Content->recursive = 5;
		$events = $this->CalendarCategory->Content->find('all', array('conditions'=>array('Content.class_name'=>'events', 'Content.parent_id'=>$eventcategory['Content']['id'])));
		
		
		
		$this->set('events', $events);
	
	}

	
	function admin_index() {
		$this->CalendarCategory->recursive = 0;

		//$this->paginate['order'] = array('Content.lft'=>'asc'); 
		$this->set('eventcategories', $this->Paginate());
	}


	function admin_add() {
		if (!empty($this->data)) {
			
			$this->CalendarCategory->create();
			$this->request->data['Content']['class_name'] = 'calendar_categories';
			$this->request->data['Content']['plugin'] = 'Calendar';
			$this->request->data['Content']['title'] = $this->data['Eventcategory']['title'];
			if ($this->CalendarCategory->saveAll($this->data)) {
				$this->Session->setFlash(sprintf(__('The %s has been saved'), 'eventcategory'));
				
				$this->redirect(array('action' => 'edit', $this->CalendarCategory->id));
			} else {
				$this->Session->setFlash(sprintf(__('The %s could not be saved. Please, try again.'), 'eventcategory'));
			}
		}
		
		$content_options = $this->CalendarCategory->Content->generateTreeList();

		$this->set(compact( 'content_options'));
	}


	function admin_edit($id = null, $version_id = null) {


		$this->CalendarCategory->id = $id; //important for read,shadow and revisions call bellow
		
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(sprintf(__('Invalid %s'), 'page'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->CalendarCategory->saveAll($this->data)) {								
				$this->Session->setFlash(sprintf(__('The %s has been saved'), 'page'));
				//$this->redirect(array('action' => 'edit', $id));
			} else {
				$this->Session->setFlash(sprintf(__('The %s could not be saved. Please, try again.'), 'page'));
			}
		}else {
			
			if (is_numeric($version_id)) {
			  $this->data = $this->CalendarCategory->read();
          	  $shadow = $this->CalendarCategory->ShadowModel->find('first',array('conditions' => array('version_id' => $version_id)));
          	  $this->data['Eventcategory'] = $shadow['Eventcategory'];
          	  
	        } else {
    	       $this->data = $this->CalendarCategory->read();
        	} 
		}

		
		
		
		$history = $this->CalendarCategory->revisions(); 
		$content_options = $this->CalendarCategory->Content->generateTreeList();
		$this->set(compact(array( 'history', 'content_options')));
	}

	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(sprintf(__('Invalid id for %s'), 'eventcategory'));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->CalendarCategory->delete($id)) {
			$this->Session->setFlash(sprintf(__('%s deleted'), 'Eventcategory'));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(sprintf(__('%s was not deleted'), 'Eventcategory'));
		$this->redirect(array('action' => 'index'));
	}
}
?>