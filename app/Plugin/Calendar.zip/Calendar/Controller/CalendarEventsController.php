<?php

class CalendarEventsController extends CalendarAppController {

	
	public $helpers = array('Html', 'Time', 'Text', 'Js', 'mTree',  'Tree', 'Image', 'TextImage', 'TractorInputs', 'Tags.TagCloud', 'Paginator', 'Number');

	public $uses = array('Calendar.CalendarEvent', 'Calendar.Eventcategory');
	
	var $permissions = array(
        'admin_index' => array('Editor'),
        'admin_add' => array('Editor'),
        'admin_edit' => array('Editor'),
        'admin_delete' => array('Editor'),                 
    );

	function admin_index() {
		$events= $this->CalendarEvent->find('all');
		$this->CalendarEvent->recursive = 2;

		$events = $this->Paginate();

		$this->set('events', $events);
	}
	
		
	 function beforeFilter() { 
    	$this->Auth->allow('view',  'index', 'latest'); 
    	
    	parent::beforeFilter();   
    	
    } 


	function latest($limit = 10, $dir ='asc', $order = 'eventstart', $conditions = array('eventend > DATE(NOW())'  ) ){


		$posts = $this->CalendarEvent->find('all', array('order' => 'CalendarEvent.' . $order . ' ' . $dir, 'limit' => $limit, 'conditions' => $conditions));	

		return $posts;	 
	}

	function index($slug) {
		
		
				
    	$content = $this->CalendarEvent->Content->find('first', array('conditions'=>array('Content.slug'=>$slug)));
    	$this->set('content', $content);
		
		$path  = $this->CalendarEvent->Content->getPath($content['Content']['id']);
		$this->set('path', $path);
		
		$this->CalendarEvent->recursive = 2;
		$events = $this->CalendarEvent->find('all', array('conditions'=>array('eventend > DATE(NOW())'  ),  'order'=>array('Event.eventstart asc')));
		foreach ($events as $event){
			$event['Eventcategory'] = $this->Eventcategory->find('first', array('conditions'=>array('Content.id'=>$event['Content']['parent_id'])));
			$events_processed[] = $event;
		}
		$this->set('events', $events_processed);
		
		$event_categories = $this->Eventcategory->Content->find('threaded', array(
			'fields' => array('id', 'title', 'path', 'slug',  'lft', 'rght', 'parent_id'), 
			'order' => 'lft ASC',
			'conditions' => array('Content.class_name'=>'eventcategories', 'Content.action_name' =>'view')
			));
		$this->set('event_categories', $event_categories);
	}

	function view($slug = null) {


		if (!$slug) {
			$this->Session->setFlash(sprintf(__('Invalid %s'), 'page'));
			$this->redirect(array('action' => 'index'));
		}


		
		$event = $this->CalendarEvent->find('first', array('conditions'=>array('Content.slug' => $slug)));
		$path  = $this->CalendarEvent->Content->getPath($event['Content']['id']);
		
		
		
		$this->set('content', $event);		
		$this->set('path', $path);		
		$this->cacheAction = true;
		if (!empty($event['Content']['layout'])) $this->layout =  basename($page['Content']['layout'], '.ctp');
		if (!empty($event['Content']['view']))$this->render(basename($page['Content']['view'], '.ctp')) ;
		//die();
		
	}

	

	

	function admin_add() {
		if (!empty($this->data)) {
			$this->CalendarEvent->create();
			$this->data['Content']['class_name'] = 'calendar_events';
			$this->data['Content']['plugin'] = 'Calendar';
			$this->data['Content']['title'] = $this->data['Event']['title'];
			
			if ($this->CalendarEvent->saveAll($this->data)) {
				$this->Session->setFlash(sprintf(__('The %s has been saved'), 'event'));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(sprintf(__('The %s could not be saved. Please, try again.'), 'event'));
			}
		}
		
		$content_options = $this->CalendarEvent->Content->generateTreeList(
															array('Content.class_name'=>'eventcategories')
											);
		

		$this->set('content_options', $content_options);

	}

	function admin_edit($id = null, $version_id = null) {
		$this->CalendarEvent->id = $id; //important for read,shadow and revisions call bellow
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid event'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->CalendarEvent->saveAll($this->data)) {
				$this->Session->setFlash(__('The event has been saved'));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The event could not be saved. Please, try again.'));
			}
		}else{			
			if (is_numeric($version_id)) {
			  $this->data = $this->CalendarEvent->read();
          	  $shadow = $this->CalendarEvent->ShadowModel->find('first',array('conditions' => array('version_id' => $version_id)));
          	  $this->data['Event'] = $shadow['Event'];          	  
	        } else {
    	       $this->data = $this->CalendarEvent->read();
        	}         
		}				
		if (empty($this->data)) {
			$this->data = $this->CalendarEvent->read(null, $id);
			
		}
		//$eventcategories = $this->CalendarEvent->Eventcategory->find('list');
		$tags = $this->CalendarEvent->Tag->find('list');
		$this->set(compact( 'tags', 'tags'));
		$history = $this->CalendarEvent->revisions(); 
		$content_options = $this->CalendarEvent->Content->generateTreeList(
															array('Content.class_name'=>'eventcategories')
											);
		$this->set(compact(array( 'history', 'content_options')));
	}





	function admin_delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(sprintf(__('Invalid id for %s'), 'event'));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->CalendarEvent->delete($id)) {
			$this->Session->setFlash(sprintf(__('%s deleted'), 'Event'));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(sprintf(__('%s was not deleted'), 'Event'));
		$this->redirect(array('action' => 'index'));
	}
}
?>