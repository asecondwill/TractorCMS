<?php
Configure::write('contenttypes', 
	array(
		array(
		'title'=> 'Calendar',
		'path'=>'', 
		'children'=>array(
			array('path'=>'/admin/calendar/calendar_events', 'title'=>'Event'), 
			array('path'=>'/admin/calendar/calendar_categories', 'title'=>'Event Categories'), 
		)
	)
));

